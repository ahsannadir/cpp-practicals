﻿// Practical 09 || SLO 13.3.3
#include <iostream>
#include <cstring>
using namespace std;

int main(){
	char word1[25], word2[25];
	int result;
	cout << "[ Compare Words]\n";
	cout << "Enter Word 1: ";
	cin >> word1;
	cout << "Enter Word 2: ";
	cin >> word2;
	result = strcmp(word1, word2);
	if(result == 0){
		cout << "The Two Words Are Are Same.";
	} else {
		cout << "The Two Words Are Different.";
	}
}
