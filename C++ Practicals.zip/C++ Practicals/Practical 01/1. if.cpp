﻿// Practical 01 || SLO 12.1.2
#include <iostream>
using namespace std;

int main(){
	int age;
	cout << "Enter Your Age in Years: ";
	cin >> age;
	if(age >= 18){
		cout << "Your Are Eligible To Apply For CNIC.";
	}
}
