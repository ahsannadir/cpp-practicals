﻿// Practical 03 || SLO 12.1.5
#include <iostream>
using namespace std;

int main(){
	char input;
	cout << "Enter Any Letter between (a-j): ";
	cin >> input;
	switch(input){
		case 'a':
		cout << "A For Apple";
		break;
		case 'b':
		cout << "B For Ball";
		break;
		case 'c':
		cout << "C For Cat";
		break;
		case 'd':
		cout << "D For Dog";
		break;
		case 'e':
		cout << "E For Egg";
		break;
		case 'f':
		cout << "F For Fish";
		break;
		case 'g':
		cout << "G For Garden";
		break;
		case 'h':
		cout << "H For Hen";
		break;
		case 'i':
		cout << "I For Indeed";
		break;
		case 'j':
		cout << "J For Joker";
		break;
	}
}
